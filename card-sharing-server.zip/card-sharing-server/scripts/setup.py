#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Card Sharing Server Setup Script
Initializes the server environment and database
"""

import os
import sys
import sqlite3
import json
import subprocess
from pathlib import Path

def create_directories():
    """Create necessary directories"""
    directories = [
        'logs',
        'config',
        'data',
        'backend/protocols',
        'backend/database', 
        'backend/utils',
        'frontend/css',
        'frontend/js',
        'frontend/assets'
    ]
    
    for directory in directories:
        os.makedirs(directory, exist_ok=True)
        print(f"✅ Created directory: {directory}")

def create_config_file():
    """Create default configuration file"""
    config = {
        "server": {
            "host": "127.0.0.1",
            "web_port": 8080,
            "name": "Card Sharing Server"
        },
        "ports": {
            "cccam": 50000,
            "newcamd": 50001,
            "mgcamd": 50002,
            "oscam": 50003
        },
        "database": {
            "path": "cardsharing.db",
            "backup_interval": 3600
        },
        "security": {
            "max_clients_per_ip": 10,
            "session_timeout": 1800,
            "failed_login_lockout": 300,
            "default_username": "admin",
            "default_password": "alen"
        },
        "logging": {
            "level": "INFO",
            "file": "logs/cardsharing.log",
            "max_size": "10MB",
            "backup_count": 5
        }
    }
    
    with open('config/config.json', 'w') as f:
        json.dump(config, f, indent=2)
    print("✅ Created configuration file: config/config.json")

def initialize_database():
    """Initialize SQLite database"""
    conn = sqlite3.connect('cardsharing.db')
    cursor = conn.cursor()
    
    # Servers table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS servers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            hostname TEXT NOT NULL,
            port INTEGER NOT NULL,
            username TEXT NOT NULL,
            password TEXT NOT NULL,
            protocol TEXT NOT NULL,
            enabled BOOLEAN DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_check TIMESTAMP,
            status TEXT DEFAULT 'unknown'
        )
    ''')
    
    # Clients table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS clients (
            id TEXT PRIMARY KEY,
            ip_address TEXT NOT NULL,
            username TEXT,
            protocol TEXT,
            connected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_activity TIMESTAMP,
            bytes_sent INTEGER DEFAULT 0,
            bytes_received INTEGER DEFAULT 0,
            status TEXT DEFAULT 'connected'
        )
    ''')
    
    # Logs table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            level TEXT NOT NULL,
            message TEXT NOT NULL,
            source TEXT,
            client_id TEXT
        )
    ''')
    
    # Configuration table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS config (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    conn.commit()
    conn.close()
    print("✅ Initialized database: cardsharing.db")

def create_init_files():
    """Create __init__.py files for Python packages"""
    init_files = [
        'backend/__init__.py',
        'backend/protocols/__init__.py',
        'backend/database/__init__.py',
        'backend/utils/__init__.py'
    ]
    
    for init_file in init_files:
        with open(init_file, 'w') as f:
            f.write(f'# {os.path.dirname(init_file)} package\n')
        print(f"✅ Created: {init_file}")

def create_gitkeep_files():
    """Create .gitkeep files for empty directories"""
    gitkeep_files = [
        'logs/.gitkeep',
        'data/.gitkeep',
        'frontend/assets/.gitkeep'
    ]
    
    for gitkeep_file in gitkeep_files:
        with open(gitkeep_file, 'w') as f:
            f.write('# Keep this directory in git\n')
        print(f"✅ Created: {gitkeep_file}")

def create_start_script():
    """Create start script"""
    # Linux/Mac start script
    start_sh_content = '''#!/bin/bash
echo "🛰️ Starting Card Sharing Server..."
echo "📋 Checking Python dependencies..."

if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 not found. Please install Python 3.7 or higher."
    exit 1
fi

echo "📦 Installing/Updating dependencies..."
python3 -m pip install -r requirements.txt

echo "🚀 Starting server..."
python3 backend/server.py
'''
    
    with open('scripts/start.sh', 'w') as f:
        f.write(start_sh_content)
    
    # Make executable on Unix systems
    if os.name != 'nt':
        os.chmod('scripts/start.sh', 0o755)
    
    # Windows start script
    start_bat_content = '''@echo off
echo 🛰️ Starting Card Sharing Server...
echo 📋 Checking Python dependencies...

python --version >nul 2>&1
if errorlevel 1 (
    echo ❌ Python not found. Please install Python 3.7 or higher.
    pause
    exit /b 1
)

echo 📦 Installing/Updating dependencies...
python -m pip install -r requirements.txt

echo 🚀 Starting server...
python backend/server.py
pause
'''
    
    with open('scripts/start.bat', 'w') as f:
        f.write(start_bat_content)
    
    print("✅ Created start scripts: start.sh and start.bat")

def install_dependencies():
    """Install Python dependencies"""
    try:
        print("📦 Installing Python dependencies...")
        subprocess.check_call([sys.executable, '-m', 'pip', 'install', '-r', 'requirements.txt'])
        print("✅ Dependencies installed successfully")
    except subprocess.CalledProcessError:
        print("⚠️ Failed to install dependencies automatically")
        print("Please run: pip install -r requirements.txt")

def check_ports():
    """Check if required ports are available"""
    import socket
    
    ports_to_check = [8080, 50000, 50001, 50002, 50003]
    unavailable_ports = []
    
    for port in ports_to_check:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        result = sock.connect_ex(('127.0.0.1', port))
        if result == 0:
            unavailable_ports.append(port)
        sock.close()
    
    if unavailable_ports:
        print(f"⚠️ Warning: The following ports are in use: {unavailable_ports}")
        print("You may need to change ports in config/config.json")
    else:
        print("✅ All required ports are available")

def create_sample_files():
    """Create sample configuration files"""
    
    # Sample C-line file
    sample_clines = '''# Sample C-lines for testing
# Replace these with your actual C-lines
# Format: C: hostname port username password

# Example C-lines (these won't work, get real ones from your provider)
# C: server1.example.com 12000 user1 pass1
# C: server2.example.com 12001 user2 pass2
'''
    
    with open('data/sample-clines.txt', 'w') as f:
        f.write(sample_clines)
    print("✅ Created sample C-lines file: data/sample-clines.txt")

def print_setup_complete():
    """Print setup completion message"""
    print("\n" + "="*60)
    print("🎉 CARD SHARING SERVER SETUP COMPLETE!")
    print("="*60)
    print("\n📋 Next Steps:")
    print("1. Start the server:")
    print("   • Linux/Mac: ./scripts/start.sh")
    print("   • Windows: scripts\\start.bat")
    print("   • Manual: python backend/server.py")
    print("\n2. Open web interface:")
    print("   • URL: http://localhost:8080")
    print("   • Username: admin")
    print("   • Password: alen")
    print("\n3. Add your C-lines:")
    print("   • Click 'Add Server' in the dashboard")
    print("   • Enter your C-line: C: hostname port user pass")
    print("\n4. Configure your receiver:")
    print("   • Protocol: CCcam")
    print("   • Server: 127.0.0.1")
    print("   • Port: 50000")
    print("   • Username: admin")
    print("   • Password: alen")
    print("\n🛰️ Your Card Sharing Server is ready!")
    print("="*60)

def main():
    """Main setup function"""
    print("🛰️ Card Sharing Server Setup")
    print("="*40)
    
    try:
        print("\n📁 Creating directories...")
        create_directories()
        
        print("\n⚙️ Creating configuration...")
        create_config_file()
        
        print("\n🗄️ Initializing database...")
        initialize_database()
        
        print("\n📝 Creating Python package files...")
        create_init_files()
        
        print("\n📁 Creating placeholder files...")
        create_gitkeep_files()
        
        print("\n🚀 Creating start scripts...")
        create_start_script()
        
        print("\n📦 Creating sample files...")
        create_sample_files()
        
        print("\n🔍 Checking ports...")
        check_ports()
        
        # Optional dependency installation
        install_deps = input("\n📦 Install Python dependencies now? (y/n): ").lower().strip()
        if install_deps in ['y', 'yes']:
            install_dependencies()
        
        print_setup_complete()
        
    except Exception as e:
        print(f"\n❌ Setup failed: {e}")
        print("Please check the error and try again.")
        sys.exit(1)

if __name__ == "__main__":
    main()