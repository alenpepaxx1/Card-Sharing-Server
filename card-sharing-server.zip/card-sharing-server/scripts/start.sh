#!/bin/bash
echo "Starting Card Sharing Server..."
python backend/server.py