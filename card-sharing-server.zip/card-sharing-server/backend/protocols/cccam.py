#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CCcam Protocol Handler
Implements CCcam card sharing protocol
"""

import socket
import threading
import struct
import hashlib
import time
from datetime import datetime

class CCcamProtocol:
    def __init__(self, port=50000):
        self.port = port
        self.version = "2.3.0"
        self.clients = {}
        self.running = False
        self.server_socket = None
    
    def start_server(self):
        """Start CCcam server"""
        self.running = True
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        
        try:
            self.server_socket.bind(('127.0.0.1', self.port))
            self.server_socket.listen(10)
            print(f"CCcam server listening on port {self.port}")
            
            while self.running:
                try:
                    client_socket, address = self.server_socket.accept()
                    client_thread = threading.Thread(
                        target=self.handle_client,
                        args=(client_socket, address),
                        daemon=True
                    )
                    client_thread.start()
                except socket.error:
                    break
        except Exception as e:
            print(f"CCcam server error: {e}")
        finally:
            if self.server_socket:
                self.server_socket.close()
    
    def handle_client(self, client_socket, address):
        """Handle CCcam client connection"""
        client_id = f"{address[0]}:{address[1]}"
        print(f"CCcam client connected: {client_id}")
        
        try:
            # CCcam handshake
            if self.perform_handshake(client_socket, client_id):
                self.clients[client_id] = {
                    'socket': client_socket,
                    'address': address,
                    'connected_at': datetime.now(),
                    'authenticated': True,
                    'protocol': 'cccam'
                }
                
                # Handle client communication
                while self.running:
                    try:
                        data = client_socket.recv(1024)
                        if not data:
                            break
                        
                        # Process CCcam data
                        response = self.process_data(data, client_id)
                        if response:
                            client_socket.send(response)
                            
                    except socket.timeout:
                        continue
                    except socket.error:
                        break
        except Exception as e:
            print(f"CCcam client {client_id} error: {e}")
        finally:
            if client_id in self.clients:
                del self.clients[client_id]
            client_socket.close()
            print(f"CCcam client disconnected: {client_id}")
    
    def perform_handshake(self, client_socket, client_id):
        """Perform CCcam handshake"""
        try:
            # Send CCcam hello
            hello = f"CCcam {self.version}\n".encode()
            client_socket.send(hello)
            
            # Wait for client response
            client_socket.settimeout(30)
            response = client_socket.recv(1024)
            
            # Simple authentication (you can implement more complex logic)
            if b'admin' in response or b'user' in response:
                auth_ok = b"Authentication successful\n"
                client_socket.send(auth_ok)
                return True
            else:
                auth_fail = b"Authentication failed\n"
                client_socket.send(auth_fail)
                return False
                
        except Exception as e:
            print(f"CCcam handshake error for {client_id}: {e}")
            return False
    
    def process_data(self, data, client_id):
        """Process CCcam protocol data"""
        try:
            # This is a simplified implementation
            # In a real implementation, you would parse CCcam protocol messages
            
            if len(data) > 0:
                # Echo response for now (implement actual protocol logic)
                return b"CCcam response\n"
            
        except Exception as e:
            print(f"Error processing CCcam data from {client_id}: {e}")
        
        return None
    
    def stop_server(self):
        """Stop CCcam server"""
        self.running = False
        if self.server_socket:
            self.server_socket.close()
        
        # Close all client connections
        for client_id, client_info in self.clients.items():
            try:
                client_info['socket'].close()
            except:
                pass
        
        self.clients.clear()
        print("CCcam server stopped")