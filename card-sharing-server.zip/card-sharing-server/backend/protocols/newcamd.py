#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NewCamd Protocol Handler
Implements NewCamd card sharing protocol
"""

import socket
import threading
import struct
import time
from datetime import datetime

class NewCamdProtocol:
    def __init__(self, port=50001):
        self.port = port
        self.des_key = "0102030405060708091011121314"
        self.clients = {}
        self.running = False
        self.server_socket = None
    
    def start_server(self):
        """Start NewCamd server"""
        self.running = True
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        
        try:
            self.server_socket.bind(('127.0.0.1', self.port))
            self.server_socket.listen(10)
            print(f"NewCamd server listening on port {self.port}")
            
            while self.running:
                try:
                    client_socket, address = self.server_socket.accept()
                    client_thread = threading.Thread(
                        target=self.handle_client,
                        args=(client_socket, address),
                        daemon=True
                    )
                    client_thread.start()
                except socket.error:
                    break
        except Exception as e:
            print(f"NewCamd server error: {e}")
        finally:
            if self.server_socket:
                self.server_socket.close()
    
    def handle_client(self, client_socket, address):
        """Handle NewCamd client connection"""
        client_id = f"{address[0]}:{address[1]}"
        print(f"NewCamd client connected: {client_id}")
        
        try:
            # NewCamd handshake
            if self.perform_handshake(client_socket, client_id):
                self.clients[client_id] = {
                    'socket': client_socket,
                    'address': address,
                    'connected_at': datetime.now(),
                    'authenticated': True,
                    'protocol': 'newcamd'
                }
                
                # Handle client communication
                while self.running:
                    try:
                        data = client_socket.recv(1024)
                        if not data:
                            break
                        
                        # Process NewCamd data
                        response = self.process_data(data, client_id)
                        if response:
                            client_socket.send(response)
                            
                    except socket.timeout:
                        continue
                    except socket.error:
                        break
        except Exception as e:
            print(f"NewCamd client {client_id} error: {e}")
        finally:
            if client_id in self.clients:
                del self.clients[client_id]
            client_socket.close()
            print(f"NewCamd client disconnected: {client_id}")
    
    def perform_handshake(self, client_socket, client_id):
        """Perform NewCamd handshake"""
        try:
            # Send NewCamd hello
            hello = b"NewCamd Server Ready\n"
            client_socket.send(hello)
            
            # Wait for client response
            client_socket.settimeout(30)
            response = client_socket.recv(1024)
            
            # Simple authentication
            if len(response) > 0:
                auth_ok = b"NewCamd Authentication OK\n"
                client_socket.send(auth_ok)
                return True
            else:
                auth_fail = b"NewCamd Authentication failed\n"
                client_socket.send(auth_fail)
                return False
                
        except Exception as e:
            print(f"NewCamd handshake error for {client_id}: {e}")
            return False
    
    def process_data(self, data, client_id):
        """Process NewCamd protocol data"""
        try:
            # Simplified NewCamd data processing
            if len(data) > 0:
                # Echo response for now
                return b"NewCamd response\n"
            
        except Exception as e:
            print(f"Error processing NewCamd data from {client_id}: {e}")
        
        return None
    
    def stop_server(self):
        """Stop NewCamd server"""
        self.running = False
        if self.server_socket:
            self.server_socket.close()
        
        # Close all client connections
        for client_id, client_info in self.clients.items():
            try:
                client_info['socket'].close()
            except:
                pass
        
        self.clients.clear()
        print("NewCamd server stopped")