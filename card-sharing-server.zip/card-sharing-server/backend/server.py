#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Card Sharing Server - Main Server Module
Supports: CCcam, NewCamd, MGcamd, OSCam
Version: 1.0
Author: Alen Pepa
Copyright © 2025 Alen Pepa. All rights reserved.
"""

import socket
import threading
import json
import time
import sqlite3
import logging
import os
from datetime import datetime
from flask import Flask, render_template, request, jsonify, send_from_directory
from flask_socketio import SocketIO, emit
from protocols.cccam import CCcamProtocol
from protocols.newcamd import NewCamdProtocol
from protocols.mgcamd import MGcamdProtocol
from protocols.oscam import OSCamProtocol
from utils.config import Config
from utils.logger import setup_logger
from database.models import Database

class CardSharingServer:
    def __init__(self):
        self.config = Config()
        self.logger = setup_logger()
        self.db = Database()
        self.clients = {}
        self.servers = []
        self.running = False
        
        # Initialize Flask app with correct template and static folders
        template_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'frontend'))
        static_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'frontend'))
        
        self.app = Flask(__name__, 
                        template_folder=template_dir,
                        static_folder=static_dir)
        self.app.config['SECRET_KEY'] = 'card-sharing-secret-key'
        self.socketio = SocketIO(self.app, cors_allowed_origins="*")
        
        # Initialize protocols
        self.protocols = {
            'cccam': CCcamProtocol(self.config.get('ports', 'cccam')),
            'newcamd': NewCamdProtocol(self.config.get('ports', 'newcamd')),
            'mgcamd': MGcamdProtocol(self.config.get('ports', 'mgcamd')),
            'oscam': OSCamProtocol(self.config.get('ports', 'oscam'))
        }
        
        self.setup_routes()
        self.setup_websocket_events()
    
    def setup_routes(self):
        """Setup Flask routes"""
        
        # Main page route
        @self.app.route('/')
        def index():
            return send_from_directory(self.app.template_folder, 'index.html')
        
        # Static files routes
        @self.app.route('/css/<path:filename>')
        def css_files(filename):
            return send_from_directory(os.path.join(self.app.static_folder, 'css'), filename)
        
        @self.app.route('/js/<path:filename>')
        def js_files(filename):
            return send_from_directory(os.path.join(self.app.static_folder, 'js'), filename)
        
        @self.app.route('/assets/<path:filename>')
        def asset_files(filename):
            return send_from_directory(os.path.join(self.app.static_folder, 'assets'), filename)
        
        # API Routes
        @self.app.route('/api/servers', methods=['GET'])
        def get_servers():
            servers = self.db.get_all_servers()
            return jsonify({'servers': servers})
        
        @self.app.route('/api/servers', methods=['POST'])
        def add_server():
            data = request.get_json()
            cline = data.get('cline')
            
            if self.add_upstream_server(cline):
                return jsonify({'success': True, 'message': 'Server added successfully'})
            else:
                return jsonify({'success': False, 'error': 'Invalid C-line format'}), 400
        
        @self.app.route('/api/servers/<int:server_id>', methods=['DELETE'])
        def remove_server(server_id):
            if self.db.remove_server(server_id):
                return jsonify({'success': True})
            else:
                return jsonify({'success': False, 'error': 'Server not found'}), 404
        
        @self.app.route('/api/servers/<int:server_id>/test', methods=['POST'])
        def test_server(server_id):
            server = self.db.get_server(server_id)
            if server:
                result = self.test_server_connection(server)
                return jsonify({'success': result})
            else:
                return jsonify({'success': False, 'error': 'Server not found'}), 404
        
        @self.app.route('/api/clients', methods=['GET'])
        def get_clients():
            clients = list(self.clients.values())
            return jsonify({'clients': clients})
        
        @self.app.route('/api/stats', methods=['GET'])
        def get_stats():
            return jsonify({
                'uptime': self.get_uptime(),
                'total_clients': len(self.clients),
                'active_servers': len([s for s in self.servers if s.get('status') == 'online']),
                'protocols': list(self.protocols.keys())
            })
        
        @self.app.route('/api/logs', methods=['GET'])
        def get_logs():
            logs = self.db.get_logs()
            return jsonify({'logs': logs})
        
        @self.app.route('/api/config', methods=['GET'])
        def get_config():
            return jsonify(self.config.get_all())
        
        @self.app.route('/api/config', methods=['PUT'])
        def update_config():
            data = request.get_json()
            # Update configuration logic here
            return jsonify({'success': True, 'message': 'Configuration updated'})
    
    def setup_websocket_events(self):
        """Setup WebSocket events"""
        @self.socketio.on('connect')
        def handle_connect():
            self.logger.info(f"WebSocket client connected: {request.sid}")
        
        @self.socketio.on('disconnect')
        def handle_disconnect():
            self.logger.info(f"WebSocket client disconnected: {request.sid}")
    
    def add_upstream_server(self, server_line):
        """Add upstream server from C-line format"""
        try:
            parts = server_line.strip().split()
            if len(parts) >= 5 and parts[0] == 'C:':
                server = {
                    'hostname': parts[1],
                    'port': int(parts[2]),
                    'username': parts[3],
                    'password': parts[4],
                    'protocol': 'cccam',
                    'enabled': True,
                    'created_at': datetime.now().isoformat()
                }
                
                server_id = self.db.add_server(server)
                if server_id:
                    server['id'] = server_id
                    self.servers.append(server)
                    self.logger.info(f"Added upstream server: {server['hostname']}:{server['port']}")
                    return True
            return False
        except Exception as e:
            self.logger.error(f"Error adding upstream server: {e}")
            return False
    
    def test_server_connection(self, server):
        """Test connection to upstream server"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(10)
            result = sock.connect_ex((server['hostname'], server['port']))
            sock.close()
            return result == 0
        except Exception as e:
            self.logger.error(f"Error testing server {server['hostname']}: {e}")
            return False
    
    def start_protocol_servers(self):
        """Start all protocol servers"""
        for protocol_name, protocol in self.protocols.items():
            thread = threading.Thread(target=protocol.start_server, daemon=True)
            thread.start()
            self.logger.info(f"{protocol_name.upper()} server started on port {protocol.port}")
    
    def start_web_server(self):
        """Start the web server"""
        web_port = self.config.get('server', 'web_port', 8080)
        host = self.config.get('server', 'host', '127.0.0.1')
        
        self.logger.info(f"Starting web server on {host}:{web_port}")
        self.socketio.run(self.app, host=host, port=web_port, debug=False)
    
    def get_uptime(self):
        """Get server uptime"""
        if hasattr(self, 'start_time'):
            uptime_seconds = time.time() - self.start_time
            hours = int(uptime_seconds // 3600)
            minutes = int((uptime_seconds % 3600) // 60)
            return f"{hours}h {minutes}m"
        return "0h 0m"
    
    def start(self):
        """Start the complete server system"""
        self.start_time = time.time()
        self.running = True
        
        self.logger.info("Starting Card Sharing Server...")
        
        # Start protocol servers
        self.start_protocol_servers()
        
        # Start web server (this will block)
        self.start_web_server()

if __name__ == "__main__":
    server = CardSharingServer()
    try:
        server.start()
    except KeyboardInterrupt:
        print("\nShutting down server...")
    except Exception as e:
        print(f"Server error: {e}")