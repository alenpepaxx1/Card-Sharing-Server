#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Logging System
Configures application logging
"""

import logging
import logging.handlers
import os
from pathlib import Path

def setup_logger(name='cardsharing', log_file='logs/cardsharing.log', level=logging.INFO):
    """Setup application logger"""
    
    # Create logs directory if it doesn't exist
    log_dir = os.path.dirname(log_file)
    if log_dir:
        os.makedirs(log_dir, exist_ok=True)
    
    # Create logger
    logger = logging.getLogger(name)
    logger.setLevel(level)
    
    # Clear existing handlers
    logger.handlers.clear()
    
    # Create formatters
    detailed_formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    simple_formatter = logging.Formatter(
        '%(levelname)s: %(message)s'
    )
    
    # File handler with rotation
    if log_file:
        file_handler = logging.handlers.RotatingFileHandler(
            log_file,
            maxBytes=10*1024*1024,  # 10MB
            backupCount=5
        )
        file_handler.setLevel(level)
        file_handler.setFormatter(detailed_formatter)
        logger.addHandler(file_handler)
    
    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(level)
    console_handler.setFormatter(simple_formatter)
    logger.addHandler(console_handler)
    
    return logger

class CardSharingLogHandler(logging.Handler):
    """Custom log handler for card sharing events"""
    
    def __init__(self, database=None):
        super().__init__()
        self.database = database
    
    def emit(self, record):
        """Emit log record to database"""
        if self.database:
            try:
                self.database.add_log(
                    level=record.levelname,
                    message=record.getMessage(),
                    source=record.name
                )
            except Exception:
                pass  # Don't let logging errors crash the app

def create_protocol_logger(protocol_name):
    """Create logger for specific protocol"""
    logger_name = f'cardsharing.{protocol_name.lower()}'
    logger = logging.getLogger(logger_name)
    
    # Set specific log file for protocol
    log_file = f'logs/{protocol_name.lower()}.log'
    
    # Create file handler
    if not logger.handlers:
        file_handler = logging.handlers.RotatingFileHandler(
            log_file,
            maxBytes=5*1024*1024,  # 5MB per protocol
            backupCount=3
        )
        
        formatter = logging.Formatter(
            '%(asctime)s - %(levelname)s - %(message)s'
        )
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
        logger.setLevel(logging.INFO)
    
    return logger

def log_client_activity(logger, client_id, action, details=None):
    """Log client activity"""
    message = f"Client {client_id}: {action}"
    if details:
        message += f" - {details}"
    logger.info(message)

def log_server_activity(logger, server_info, action, details=None):
    """Log server activity"""
    server_name = f"{server_info.get('hostname', 'unknown')}:{server_info.get('port', 'unknown')}"
    message = f"Server {server_name}: {action}"
    if details:
        message += f" - {details}"
    logger.info(message)

def log_protocol_event(protocol_name, event, client_id=None, details=None):
    """Log protocol-specific events"""
    logger = create_protocol_logger(protocol_name)
    
    message = f"{protocol_name.upper()} - {event}"
    if client_id:
        message += f" (Client: {client_id})"
    if details:
        message += f" - {details}"
    
    logger.info(message)

class LogLevel:
    """Log level constants"""
    DEBUG = logging.DEBUG
    INFO = logging.INFO
    WARNING = logging.WARNING
    ERROR = logging.ERROR
    CRITICAL = logging.CRITICAL

# Utility functions for common logging patterns
def log_startup(logger, component, port=None):
    """Log component startup"""
    message = f"{component} started"
    if port:
        message += f" on port {port}"
    logger.info(message)

def log_shutdown(logger, component):
    """Log component shutdown"""
    logger.info(f"{component} stopped")

def log_error(logger, operation, error, client_id=None):
    """Log error with context"""
    message = f"Error in {operation}: {error}"
    if client_id:
        message += f" (Client: {client_id})"
    logger.error(message)

def log_connection(logger, client_id, protocol, action="connected"):
    """Log client connection events"""
    message = f"Client {client_id} {action} via {protocol.upper()}"
    logger.info(message)

def log_authentication(logger, client_id, success, username=None):
    """Log authentication attempts"""
    status = "successful" if success else "failed"
    message = f"Authentication {status} for client {client_id}"
    if username:
        message += f" (username: {username})"
    
    if success:
        logger.info(message)
    else:
        logger.warning(message)

def log_data_transfer(logger, client_id, bytes_sent, bytes_received):
    """Log data transfer statistics"""
    message = f"Client {client_id} - Sent: {bytes_sent}B, Received: {bytes_received}B"
    logger.debug(message)

def log_server_test(logger, server_info, success, response_time=None):
    """Log server connectivity tests"""
    server_name = f"{server_info.get('hostname')}:{server_info.get('port')}"
    status = "online" if success else "offline"
    message = f"Server test - {server_name}: {status}"
    
    if success and response_time:
        message += f" (Response time: {response_time:.2f}ms)"
    
    if success:
        logger.info(message)
    else:
        logger.warning(message)

# Configuration helper
def configure_logging_from_config(config):
    """Configure logging based on configuration object"""
    log_config = config.get('logging', {})
    
    level_str = log_config.get('level', 'INFO')
    level = getattr(logging, level_str.upper(), logging.INFO)
    
    log_file = log_config.get('file', 'logs/cardsharing.log')
    
    return setup_logger(level=level, log_file=log_file)