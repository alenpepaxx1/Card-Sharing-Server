#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Configuration Manager
Handles application configuration
"""

import json
import os
from pathlib import Path

class Config:
    def __init__(self, config_path='config/config.json'):
        self.config_path = config_path
        self.config = self.load_config()
    
    def load_config(self):
        """Load configuration from file"""
        try:
            if os.path.exists(self.config_path):
                with open(self.config_path, 'r') as f:
                    return json.load(f)
            else:
                # Return default configuration
                return self.get_default_config()
        except Exception as e:
            print(f"Error loading config: {e}")
            return self.get_default_config()
    
    def get_default_config(self):
        """Get default configuration"""
        return {
            "server": {
                "host": "127.0.0.1",
                "web_port": 8080,
                "name": "Card Sharing Server"
            },
            "ports": {
                "cccam": 50000,
                "newcamd": 50001,
                "mgcamd": 50002,
                "oscam": 50003
            },
            "database": {
                "path": "cardsharing.db",
                "backup_interval": 3600
            },
            "security": {
                "max_clients_per_ip": 10,
                "session_timeout": 1800,
                "failed_login_lockout": 300,
                "default_username": "admin",
                "default_password": "alen"
            },
            "logging": {
                "level": "INFO",
                "file": "logs/cardsharing.log",
                "max_size": "10MB",
                "backup_count": 5
            }
        }
    
    def get(self, section, key=None, default=None):
        """Get configuration value"""
        try:
            if key is None:
                return self.config.get(section, default)
            return self.config.get(section, {}).get(key, default)
        except Exception:
            return default
    
    def set(self, section, key, value):
        """Set configuration value"""
        if section not in self.config:
            self.config[section] = {}
        self.config[section][key] = value
    
    def save_config(self):
        """Save configuration to file"""
        try:
            # Create config directory if it doesn't exist
            os.makedirs(os.path.dirname(self.config_path), exist_ok=True)
            
            with open(self.config_path, 'w') as f:
                json.dump(self.config, f, indent=2)
            return True
        except Exception as e:
            print(f"Error saving config: {e}")
            return False
    
    def get_all(self):
        """Get all configuration"""
        return self.config.copy()