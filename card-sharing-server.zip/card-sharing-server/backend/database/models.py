#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Database Models and Operations
Handles SQLite database operations for card sharing server
"""

import sqlite3
import json
import logging
from datetime import datetime
from contextlib import contextmanager

class Database:
    def __init__(self, db_path='cardsharing.db'):
        self.db_path = db_path
        self.logger = logging.getLogger(__name__)
        self.init_database()
    
    def init_database(self):
        """Initialize database with required tables"""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            
            # Servers table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS servers (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    hostname TEXT NOT NULL,
                    port INTEGER NOT NULL,
                    username TEXT NOT NULL,
                    password TEXT NOT NULL,
                    protocol TEXT NOT NULL,
                    enabled BOOLEAN DEFAULT 1,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    last_check TIMESTAMP,
                    status TEXT DEFAULT 'unknown'
                )
            ''')
            
            # Clients table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS clients (
                    id TEXT PRIMARY KEY,
                    ip_address TEXT NOT NULL,
                    username TEXT,
                    protocol TEXT,
                    connected_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    last_activity TIMESTAMP,
                    bytes_sent INTEGER DEFAULT 0,
                    bytes_received INTEGER DEFAULT 0,
                    status TEXT DEFAULT 'connected'
                )
            ''')
            
            # Logs table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    level TEXT NOT NULL,
                    message TEXT NOT NULL,
                    source TEXT,
                    client_id TEXT
                )
            ''')
            
            # Configuration table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS config (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            
            conn.commit()
            self.logger.info("Database initialized successfully")
    
    @contextmanager
    def get_connection(self):
        """Get database connection with context manager"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
        except Exception as e:
            conn.rollback()
            self.logger.error(f"Database error: {e}")
            raise
        finally:
            conn.close()
    
    def add_server(self, server_data):
        """Add a new upstream server"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT INTO servers (hostname, port, username, password, protocol, enabled)
                    VALUES (?, ?, ?, ?, ?, ?)
                ''', (
                    server_data['hostname'],
                    server_data['port'],
                    server_data['username'],
                    server_data['password'],
                    server_data['protocol'],
                    server_data.get('enabled', True)
                ))
                conn.commit()
                return cursor.lastrowid
        except Exception as e:
            self.logger.error(f"Error adding server: {e}")
            return None
    
    def get_all_servers(self):
        """Get all servers"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('SELECT * FROM servers ORDER BY created_at DESC')
                return [dict(row) for row in cursor.fetchall()]
        except Exception as e:
            self.logger.error(f"Error getting servers: {e}")
            return []
    
    def get_server(self, server_id):
        """Get server by ID"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('SELECT * FROM servers WHERE id = ?', (server_id,))
                row = cursor.fetchone()
                return dict(row) if row else None
        except Exception as e:
            self.logger.error(f"Error getting server {server_id}: {e}")
            return None
    
    def update_server_status(self, server_id, status):
        """Update server status"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    UPDATE servers 
                    SET status = ?, last_check = CURRENT_TIMESTAMP 
                    WHERE id = ?
                ''', (status, server_id))
                conn.commit()
                return cursor.rowcount > 0
        except Exception as e:
            self.logger.error(f"Error updating server status: {e}")
            return False
    
    def remove_server(self, server_id):
        """Remove server by ID"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('DELETE FROM servers WHERE id = ?', (server_id,))
                conn.commit()
                return cursor.rowcount > 0
        except Exception as e:
            self.logger.error(f"Error removing server: {e}")
            return False
    
    def add_client(self, client_data):
        """Add or update client information"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT OR REPLACE INTO clients 
                    (id, ip_address, username, protocol, connected_at, last_activity, status)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ''', (
                    client_data['id'],
                    client_data['ip_address'],
                    client_data.get('username'),
                    client_data.get('protocol'),
                    client_data.get('connected_at', datetime.now().isoformat()),
                    datetime.now().isoformat(),
                    client_data.get('status', 'connected')
                ))
                conn.commit()
                return True
        except Exception as e:
            self.logger.error(f"Error adding client: {e}")
            return False
    
    def get_all_clients(self):
        """Get all clients"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('SELECT * FROM clients ORDER BY connected_at DESC')
                return [dict(row) for row in cursor.fetchall()]
        except Exception as e:
            self.logger.error(f"Error getting clients: {e}")
            return []
    
    def remove_client(self, client_id):
        """Remove client by ID"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('DELETE FROM clients WHERE id = ?', (client_id,))
                conn.commit()
                return cursor.rowcount > 0
        except Exception as e:
            self.logger.error(f"Error removing client: {e}")
            return False
    
    def add_log(self, level, message, source=None, client_id=None):
        """Add log entry"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT INTO logs (level, message, source, client_id)
                    VALUES (?, ?, ?, ?)
                ''', (level, message, source, client_id))
                conn.commit()
                return True
        except Exception as e:
            self.logger.error(f"Error adding log: {e}")
            return False
    
    def get_logs(self, limit=100):
        """Get recent logs"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    SELECT * FROM logs 
                    ORDER BY timestamp DESC 
                    LIMIT ?
                ''', (limit,))
                return [dict(row) for row in cursor.fetchall()]
        except Exception as e:
            self.logger.error(f"Error getting logs: {e}")
            return []
    
    def set_config(self, key, value):
        """Set configuration value"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT OR REPLACE INTO config (key, value, updated_at)
                    VALUES (?, ?, CURRENT_TIMESTAMP)
                ''', (key, json.dumps(value) if not isinstance(value, str) else value))
                conn.commit()
                return True
        except Exception as e:
            self.logger.error(f"Error setting config: {e}")
            return False
    
    def get_config(self, key, default=None):
        """Get configuration value"""
        try:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('SELECT value FROM config WHERE key = ?', (key,))
                row = cursor.fetchone()
                if row:
                    try:
                        return json.loads(row['value'])
                    except json.JSONDecodeError:
                        return row['value']
                return default
        except Exception as e:
            self.logger.error(f"Error getting config: {e}")
            return default