# README.md - Project Documentation

# Card Sharing WebServer

## Overview

A modern, web-based card sharing server that supports multiple protocols including CCcam, NewCamd, MGcamd, and OSCam. Features a beautiful web interface for server management and real-time monitoring.

## 🚀 Features

- **Multi-Protocol Support**: CCcam, NewCamd, MGcamd, OSCam
- **Modern Web Interface**: Clean, responsive dashboard with real-time updates
- **Easy Server Management**: Add/remove upstream servers via web interface
- **Real-time Monitoring**: Live client connections, server status, and statistics
- **C-line Processing**: Simple input format: `C: hostname port username password`
- **Local Sharing**: Creates local server accessible at `C: 127.0.0.1 50000 admin alen`
- **WebSocket Support**: Real-time updates without page refresh
- **SQLite Database**: Lightweight, embedded database for configuration storage
- **Logging System**: Comprehensive logging with web-based log viewer

## 📋 Requirements

- Python 3.7 or higher
- Modern web browser (Chrome, Firefox, Safari, Edge)
- Network access for upstream servers

## 🛠️ Installation

### Quick Start

1. **Download the project**:
    
    ```bash
    git clone https://github.com/your-username/card-sharing-server.git
    cd card-sharing-server
    ```
    
2. **Install dependencies**:
    
    ```bash
    pip install -r requirements.txt
    ```
    
3. **Start the server**:
    
    ```bash
    python backend/[server.py](http://server.py)
    ```
    
4. **Open web interface**:
    
    ```
    http://127.0.0.1:8080
    ```
    

### Advanced Installation

1. **Create virtual environment**:
    
    ```bash
    python -m venv cardsharing-env
    source cardsharing-env/bin/activate  # Linux/Mac
    # or
    cardsharing-env\Scripts\activate     # Windows
    ```
    
2. **Install dependencies**:
    
    ```bash
    pip install -r requirements.txt
    ```
    
3. **Configure server** (optional):
    
    ```bash
    cp config/config.json config/config.json.local
    # Edit config/config.json.local with your settings
    ```
    
4. **Start server**:
    
    ```bash
    python backend/[server.py](http://server.py)
    ```
    

## 🖥️ Usage

### Adding an Upstream Server

1. Open the web interface at [`http://127.0.0.1:8080`](http://127.0.0.1:8080)
2. Go to the **Servers** section
3. Click **"+ Add Server"**
4. Enter your C-line: `C: [free.cccamia.com](http://free.cccamia.com) 18000 nhe4i4 [CCcamia.com](http://CCcamia.com)`
5. Click **"Add Server"**

### Configuring Your Receiver

Use these settings in your satellite receiver:

```
Protocol: CCcam
Server: 127.0.0.1
Port: 50000
Username: admin
Password: alen
```

### Multiple Protocols

The server supports multiple protocols on different ports:

- **CCcam**: Port 50000
- **NewCamd**: Port 50001
- **MGcamd**: Port 50002
- **OSCam**: Port 50003

## 📁 Project Structure

```
card-sharing-server/
├── backend/                 # Python server code
│   ├── [server.py](http://server.py)           # Main server application
│   ├── protocols/          # Protocol implementations
│   │   ├── [cccam.py](http://cccam.py)       # CCcam protocol handler
│   │   ├── [newcamd.py](http://newcamd.py)     # NewCamd protocol handler
│   │   ├── [mgcamd.py](http://mgcamd.py)      # MGcamd protocol handler
│   │   └── [oscam.py](http://oscam.py)       # OSCam protocol handler
│   ├── database/          # Database models and operations
│   │   └── [models.py](http://models.py)      # SQLite database interface
│   └── utils/             # Utility modules
│       ├── [config.py](http://config.py)      # Configuration management
│       └── [logger.py](http://logger.py)      # Logging setup
├── frontend/              # Web interface
│   ├── index.html         # Main HTML page
│   ├── css/
│   │   └── style.css      # Styling
│   └── js/
│       └── app.js         # JavaScript application
├── config/                # Configuration files
│   └── config.json        # Server configuration
├── docs/                  # Documentation
│   └── [README.md](http://README.md)          # This file
├── logs/                  # Log files (created automatically)
└── requirements.txt       # Python dependencies
```

## ⚙️ Configuration

### Web Interface Settings

- **Server Name**: Customize your server name
- **Port Configuration**: Change protocol ports
- **Security Settings**: Configure usernames, passwords, and IP limits
- **Logging Level**: Adjust log verbosity

### Configuration File

Edit `config/config.json` to customize server settings:

```json
{
  "server": {
    "host": "127.0.0.1",
    "web_port": 8080
  },
  "ports": {
    "cccam": 50000,
    "newcamd": 50001,
    "mgcamd": 50002,
    "oscam": 50003
  },
  "security": {
    "default_username": "admin",
    "default_password": "alen",
    "max_clients_per_ip": 10
  }
}
```

## 🔧 API Reference

### Server Management

- `GET /api/servers` - List all servers
- `POST /api/servers` - Add new server
- `DELETE /api/servers/{id}` - Remove server
- `POST /api/servers/{id}/test` - Test server connection

### Client Management

- `GET /api/clients` - List connected clients
- `POST /api/clients/{id}/kick` - Disconnect client

### Statistics

- `GET /api/stats` - Server statistics
- `GET /api/logs` - Recent logs

## 🐛 Troubleshooting

### Common Issues

1. **Port already in use**:
    
    ```bash
    # Check what's using the port
    netstat -tulpn | grep :8080
    
    # Kill the process or change the port in config
    ```
    
2. **Cannot connect to upstream server**:
    - Check your internet connection
    - Verify the C-line credentials
    - Ensure firewall allows outbound connections
3. **Receiver cannot connect**:
    - Check if server is running: [`http://127.0.0.1:8080`](http://127.0.0.1:8080)
    - Verify receiver settings match server configuration
    - Check firewall settings for inbound connections

### Log Files

Check `logs/cardsharing.log` for detailed error messages:

```bash
tail -f logs/cardsharing.log
```

## 📜 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/amazing-feature`
3. Commit changes: `git commit -m 'Add amazing feature'`
4. Push to branch: `git push origin feature/amazing-feature`
5. Open a Pull Request

## 📞 Support

For support and questions:

- Create an issue on GitHub
- Check the documentation
- Review the logs for error messages

## 🎯 Roadmap

- [ ]  HTTPS support
- [ ]  User authentication system
- [ ]  Advanced statistics and analytics
- [ ]  Mobile-responsive improvements
- [ ]  Docker containerization
- [ ]  Load balancing for multiple upstream servers
- [ ]  Plugin system for custom protocols

---

**Made with ❤️ by Alen Pepa**