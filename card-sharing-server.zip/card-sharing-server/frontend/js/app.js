// Card Sharing Server - Dashboard Application

class CardSharingDashboard {
    constructor() {
        this.apiUrl = '/api';
        this.wsUrl = `ws://${window.location.host}/ws`;
        this.socket = null;
        this.currentSection = 'dashboard';
        this.servers = [];
        this.clients = [];
        this.stats = {};
        this.logs = [];
        
        this.init();
    }
    
    init() {
        this.setupEventListeners();
        this.initWebSocket();
        this.loadInitialData();
        this.startPeriodicUpdates();
        
        console.log('Card Sharing Dashboard initialized');
    }
    
    setupEventListeners() {
        // Navigation
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const section = link.dataset.section;
                this.navigateToSection(section);
            });
        });
        
        // Add server form
        const addServerForm = document.getElementById('addServerForm');
        if (addServerForm) {
            addServerForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleAddServer();
            });
        }
        
        // Modal close events
        document.querySelectorAll('.modal-close').forEach(button => {
            button.addEventListener('click', (e) => {
                const modal = e.target.closest('.modal');
                this.closeModal(modal.id);
            });
        });
        
        // Click outside modal to close
        document.querySelectorAll('.modal').forEach(modal => {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    this.closeModal(modal.id);
                }
            });
        });
        
        // Log level filter
        const logFilter = document.getElementById('logLevelFilter');
        if (logFilter) {
            logFilter.addEventListener('change', () => {
                this.filterLogs();
            });
        }
    }
    
    initWebSocket() {
        try {
            this.socket = new WebSocket(this.wsUrl);
            
            this.socket.onopen = () => {
                console.log('WebSocket connected');
                this.updateServerStatus('online');
            };
            
            this.socket.onmessage = (event) => {
                const data = JSON.parse(event.data);
                this.handleWebSocketMessage(data);
            };
            
            this.socket.onclose = () => {
                console.log('WebSocket disconnected');
                this.updateServerStatus('offline');
                // Attempt to reconnect after 5 seconds
                setTimeout(() => this.initWebSocket(), 5000);
            };
            
            this.socket.onerror = (error) => {
                console.error('WebSocket error:', error);
                this.updateServerStatus('error');
            };
        } catch (error) {
            console.error('Failed to initialize WebSocket:', error);
            this.updateServerStatus('error');
        }
    }
    
    handleWebSocketMessage(data) {
        switch (data.type) {
            case 'client_connected':
                this.handleClientUpdate(data.client, 'connected');
                break;
            case 'client_disconnected':
                this.handleClientUpdate(data.client, 'disconnected');
                break;
            case 'server_status_update':
                this.handleServerStatusUpdate(data.server);
                break;
            case 'stats_update':
                this.updateStats(data.stats);
                break;
            case 'log_entry':
                this.addLogEntry(data.log);
                break;
        }
    }
    
    async loadInitialData() {
        await Promise.all([
            this.loadServers(),
            this.loadClients(),
            this.loadStats(),
            this.loadLogs()
        ]);
        
        this.renderDashboard();
    }
    
    async apiCall(endpoint, options = {}) {
        try {
            const response = await fetch(`${this.apiUrl}${endpoint}`, {
                headers: {
                    'Content-Type': 'application/json',
                    ...options.headers
                },
                ...options
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            return await response.json();
        } catch (error) {
            console.error(`API call failed: ${endpoint}`, error);
            this.showNotification(`API Error: ${error.message}`, 'error');
            throw error;
        }
    }
    
    async loadServers() {
        try {
            const data = await this.apiCall('/servers');
            this.servers = data.servers || [];
            this.renderServers();
        } catch (error) {
            console.error('Failed to load servers:', error);
        }
    }
    
    async loadClients() {
        try {
            const data = await this.apiCall('/clients');
            this.clients = data.clients || [];
            this.renderClients();
        } catch (error) {
            console.error('Failed to load clients:', error);
        }
    }
    
    async loadStats() {
        try {
            const data = await this.apiCall('/stats');
            this.stats = data;
            this.updateStats(data);
        } catch (error) {
            console.error('Failed to load stats:', error);
        }
    }
    
    async loadLogs() {
        try {
            const data = await this.apiCall('/logs');
            this.logs = data.logs || [];
            this.renderLogs();
        } catch (error) {
            console.error('Failed to load logs:', error);
        }
    }
    
    navigateToSection(sectionId) {
        // Update navigation
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.remove('active');
        });
        document.querySelector(`[data-section="${sectionId}"]`).classList.add('active');
        
        // Update sections
        document.querySelectorAll('.section').forEach(section => {
            section.classList.remove('active');
        });
        document.getElementById(`${sectionId}-section`).classList.add('active');
        
        this.currentSection = sectionId;
        
        // Load section-specific data
        this.loadSectionData(sectionId);
    }
    
    loadSectionData(sectionId) {
        switch (sectionId) {
            case 'dashboard':
                this.renderDashboard();
                break;
            case 'servers':
                this.loadServers();
                break;
            case 'clients':
                this.loadClients();
                break;
            case 'logs':
                this.loadLogs();
                break;
        }
    }
    
    renderDashboard() {
        // Update dashboard stats
        const elements = {
            dashboardClients: document.getElementById('dashboardClients'),
            dashboardServers: document.getElementById('dashboardServers'),
            serverUptime: document.getElementById('serverUptime'),
            clientCount: document.getElementById('clientCount'),
            uptimeDisplay: document.getElementById('uptimeDisplay')
        };
        
        if (elements.dashboardClients) {
            elements.dashboardClients.textContent = this.clients.length;
        }
        if (elements.dashboardServers) {
            elements.dashboardServers.textContent = this.servers.length;
        }
        if (elements.serverUptime && this.stats.uptime) {
            elements.serverUptime.textContent = this.stats.uptime;
        }
        if (elements.clientCount) {
            elements.clientCount.textContent = this.clients.length;
        }
        if (elements.uptimeDisplay && this.stats.uptime) {
            elements.uptimeDisplay.textContent = this.stats.uptime;
        }
        
        // Render recent activity
        this.renderRecentActivity();
    }
    
    renderServers() {
        const container = document.getElementById('serversList');
        if (!container) return;
        
        if (this.servers.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <h3>No servers configured</h3>
                    <p>Add your first upstream server to get started</p>
                    <button class="btn btn-primary" onclick="showAddServerModal()">+ Add Server</button>
                </div>
            `;
            return;
        }
        
        container.innerHTML = this.servers.map(server => `
            <div class="server-card" data-server-id="${server.id}">
                <div class="server-info">
                    <h4>${server.hostname}:${server.port}</h4>
                    <div class="server-details">
                        <span>User: ${server.username}</span>
                        <span>Protocol: ${server.protocol.toUpperCase()}</span>
                        <span>Added: ${this.formatDate(server.created_at)}</span>
                    </div>
                </div>
                <div class="server-status ${server.status || 'unknown'}">
                    <span class="status-dot"></span>
                    ${(server.status || 'unknown').toUpperCase()}
                </div>
                <div class="server-actions">
                    <button class="btn btn-secondary" onclick="testServer(${server.id})">🧪 Test</button>
                    <button class="btn btn-danger" onclick="removeServer(${server.id})">🗑️ Remove</button>
                </div>
            </div>
        `).join('');
    }
    
    renderClients() {
        const tbody = document.getElementById('clientsTableBody');
        if (!tbody) return;
        
        if (this.clients.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="6" style="text-align: center; padding: 2rem; color: var(--text-secondary);">
                        No clients connected
                    </td>
                </tr>
            `;
            return;
        }
        
        tbody.innerHTML = this.clients.map(client => `
            <tr>
                <td>${client.ip_address}</td>
                <td>${client.username || 'N/A'}</td>
                <td>${(client.protocol || 'unknown').toUpperCase()}</td>
                <td>${this.formatDate(client.connected_at)}</td>
                <td>
                    <span class="server-status ${client.status || 'unknown'}">
                        <span class="status-dot"></span>
                        ${(client.status || 'unknown').toUpperCase()}
                    </span>
                </td>
                <td>
                    <button class="btn btn-danger btn-sm" onclick="kickClient('${client.id}')">Kick</button>
                </td>
            </tr>
        `).join('');
    }
    
    renderLogs() {
        const container = document.getElementById('logsList');
        if (!container) return;
        
        const filteredLogs = this.getFilteredLogs();
        
        if (filteredLogs.length === 0) {
            container.innerHTML = '<div class="empty-state"><p>No logs available</p></div>';
            return;
        }
        
        container.innerHTML = filteredLogs.map(log => `
            <div class="log-entry ${log.level.toLowerCase()}">
                <span class="log-time">${this.formatDate(log.timestamp)}</span>
                <span class="log-level ${log.level.toLowerCase()}">${log.level}</span>
                <span class="log-message">${log.message}</span>
                ${log.source ? `<span class="log-source">[${log.source}]</span>` : ''}
            </div>
        `).join('');
        
        // Auto-scroll to bottom
        container.scrollTop = container.scrollHeight;
    }
    
    renderRecentActivity() {
        const container = document.getElementById('recentActivity');
        if (!container) return;
        
        // Get recent logs and client connections
        const recentItems = [
            ...this.logs.slice(-5).map(log => ({
                type: 'log',
                icon: this.getLogIcon(log.level),
                title: log.message,
                time: log.timestamp
            })),
            ...this.clients.slice(-3).map(client => ({
                type: 'client',
                icon: '👤',
                title: `Client connected: ${client.ip_address}`,
                time: client.connected_at
            }))
        ].sort((a, b) => new Date(b.time) - new Date(a.time)).slice(0, 5);
        
        if (recentItems.length === 0) {
            container.innerHTML = '<div class="empty-state"><p>No recent activity</p></div>';
            return;
        }
        
        container.innerHTML = recentItems.map(item => `
            <div class="activity-item">
                <div class="activity-icon">${item.icon}</div>
                <div class="activity-content">
                    <div class="activity-title">${item.title}</div>
                    <div class="activity-time">${this.formatTimeAgo(item.time)}</div>
                </div>
            </div>
        `).join('');
    }
    
    getFilteredLogs() {
        const filter = document.getElementById('logLevelFilter')?.value || 'all';
        if (filter === 'all') {
            return this.logs;
        }
        return this.logs.filter(log => log.level === filter);
    }
    
    getLogIcon(level) {
        const icons = {
            'ERROR': '❌',
            'WARNING': '⚠️',
            'INFO': 'ℹ️',
            'DEBUG': '🐛'
        };
        return icons[level] || 'ℹ️';
    }
    
    updateStats(stats) {
        this.stats = { ...this.stats, ...stats };
        
        // Update quick stats in sidebar
        const uptimeDisplay = document.getElementById('uptimeDisplay');
        const clientCount = document.getElementById('clientCount');
        
        if (uptimeDisplay && stats.uptime) {
            uptimeDisplay.textContent = stats.uptime;
        }
        if (clientCount && typeof stats.total_clients !== 'undefined') {
            clientCount.textContent = stats.total_clients;
        }
        
        // Update dashboard if it's the current section
        if (this.currentSection === 'dashboard') {
            this.renderDashboard();
        }
    }
    
    updateServerStatus(status) {
        const statusDot = document.getElementById('serverStatus');
        const serverAddress = document.getElementById('serverAddress');
        
        if (statusDot) {
            statusDot.className = `status-dot ${status === 'online' ? 'online' : 'offline'}`;
        }
        
        if (serverAddress) {
            const address = status === 'online' ? `Online - ${window.location.host}` : 'Offline';
            serverAddress.textContent = address;
        }
    }
    
    handleClientUpdate(client, action) {
        if (action === 'connected') {
            const existingIndex = this.clients.findIndex(c => c.id === client.id);
            if (existingIndex >= 0) {
                this.clients[existingIndex] = client;
            } else {
                this.clients.push(client);
            }
        } else if (action === 'disconnected') {
            this.clients = this.clients.filter(c => c.id !== client.id);
        }
        
        this.renderClients();
        this.renderDashboard();
    }
    
    handleServerStatusUpdate(server) {
        const serverIndex = this.servers.findIndex(s => s.id === server.id);
        if (serverIndex >= 0) {
            this.servers[serverIndex] = { ...this.servers[serverIndex], ...server };
            this.renderServers();
        }
    }
    
    addLogEntry(log) {
        this.logs.unshift(log);
        if (this.logs.length > 1000) {
            this.logs = this.logs.slice(0, 1000); // Keep only last 1000 logs
        }
        
        if (this.currentSection === 'logs') {
            this.renderLogs();
        }
        
        // Update recent activity
        this.renderRecentActivity();
    }
    
    async handleAddServer() {
        const clineInput = document.getElementById('clineInput');
        const serverNameInput = document.getElementById('serverNameInput');
        
        if (!clineInput || !clineInput.value.trim()) {
            this.showNotification('Please enter a valid C-line', 'error');
            return;
        }
        
        const cline = clineInput.value.trim();
        const serverName = serverNameInput?.value.trim() || '';
        
        try {
            const result = await this.apiCall('/servers', {
                method: 'POST',
                body: JSON.stringify({ cline, name: serverName })
            });
            
            if (result.success) {
                this.showNotification('Server added successfully', 'success');
                this.closeModal('addServerModal');
                clineInput.value = '';
                if (serverNameInput) serverNameInput.value = '';
                await this.loadServers();
            } else {
                this.showNotification(result.error || 'Failed to add server', 'error');
            }
        } catch (error) {
            console.error('Error adding server:', error);
            this.showNotification('Failed to add server', 'error');
        }
    }
    
    showModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.add('show');
            modal.style.display = 'flex';
        }
    }
    
    closeModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.classList.remove('show');
            modal.style.display = 'none';
        }
    }
    
    showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.innerHTML = `
            <span>${message}</span>
            <button onclick="this.parentElement.remove()">&times;</button>
        `;
        
        // Add to page
        document.body.appendChild(notification);
        
        // Auto remove after 5 seconds
        setTimeout(() => {
            if (notification.parentElement) {
                notification.remove();
            }
        }, 5000);
    }
    
    formatDate(dateString) {
        if (!dateString) return 'N/A';
        const date = new Date(dateString);
        return date.toLocaleString();
    }
    
    formatTimeAgo(dateString) {
        if (!dateString) return 'N/A';
        const date = new Date(dateString);
        const now = new Date();
        const diffMs = now - date;
        const diffMins = Math.floor(diffMs / 60000);
        const diffHours = Math.floor(diffMins / 60);
        const diffDays = Math.floor(diffHours / 24);
        
        if (diffMins < 1) return 'Just now';
        if (diffMins < 60) return `${diffMins}m ago`;
        if (diffHours < 24) return `${diffHours}h ago`;
        return `${diffDays}d ago`;
    }
    
    startPeriodicUpdates() {
        // Update stats every 30 seconds
        setInterval(() => {
            this.loadStats();
        }, 30000);
        
        // Update current section data every 60 seconds
        setInterval(() => {
            this.loadSectionData(this.currentSection);
        }, 60000);
    }
}

// Global functions for HTML event handlers
function showAddServerModal() {
    dashboard.showModal('addServerModal');
}

function closeModal(modalId) {
    dashboard.closeModal(modalId);
}

function refreshDashboard() {
    dashboard.loadInitialData();
}

function refreshClients() {
    dashboard.loadClients();
}

function refreshLogs() {
    dashboard.loadLogs();
}

function clearLogs() {
    if (confirm('Are you sure you want to clear all logs?')) {
        fetch('/api/logs', { method: 'DELETE' })
            .then(() => {
                dashboard.logs = [];
                dashboard.renderLogs();
                dashboard.showNotification('Logs cleared successfully', 'success');
            })
            .catch(error => {
                console.error('Error clearing logs:', error);
                dashboard.showNotification('Failed to clear logs', 'error');
            });
    }
}

async function testServer(serverId) {
    try {
        const result = await dashboard.apiCall(`/servers/${serverId}/test`, { method: 'POST' });
        const message = result.success ? 'Server is online' : 'Server is offline';
        const type = result.success ? 'success' : 'warning';
        dashboard.showNotification(message, type);
    } catch (error) {
        dashboard.showNotification('Test failed', 'error');
    }
}

async function removeServer(serverId) {
    if (confirm('Are you sure you want to remove this server?')) {
        try {
            await dashboard.apiCall(`/servers/${serverId}`, { method: 'DELETE' });
            dashboard.showNotification('Server removed successfully', 'success');
            dashboard.loadServers();
        } catch (error) {
            dashboard.showNotification('Failed to remove server', 'error');
        }
    }
}

async function kickClient(clientId) {
    if (confirm('Are you sure you want to kick this client?')) {
        try {
            await dashboard.apiCall(`/clients/${clientId}/kick`, { method: 'POST' });
            dashboard.showNotification('Client kicked successfully', 'success');
            dashboard.loadClients();
        } catch (error) {
            dashboard.showNotification('Failed to kick client', 'error');
        }
    }
}

async function testAllServers() {
    dashboard.showNotification('Testing all servers...', 'info');
    
    for (const server of dashboard.servers) {
        await testServer(server.id);
        // Add small delay between tests
        await new Promise(resolve => setTimeout(resolve, 1000));
    }
    
    dashboard.showNotification('Server testing completed', 'success');
}

function saveSettings() {
    // Collect settings from form
    const settings = {
        serverName: document.getElementById('serverName')?.value,
        webPort: document.getElementById('webPort')?.value,
        maxClientsPerIP: document.getElementById('maxClientsPerIP')?.value,
        cccamPort: document.getElementById('cccamPort')?.value,
        newcamdPort: document.getElementById('newcamdPort')?.value,
        mgcamdPort: document.getElementById('mgcamdPort')?.value,
        oscamPort: document.getElementById('oscamPort')?.value,
        defaultUsername: document.getElementById('defaultUsername')?.value,
        defaultPassword: document.getElementById('defaultPassword')?.value,
        sessionTimeout: document.getElementById('sessionTimeout')?.value
    };
    
    fetch('/api/config', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings)
    })
    .then(response => response.json())
    .then(result => {
        if (result.success) {
            dashboard.showNotification('Settings saved successfully', 'success');
        } else {
            dashboard.showNotification('Failed to save settings', 'error');
        }
    })
    .catch(error => {
        console.error('Error saving settings:', error);
        dashboard.showNotification('Failed to save settings', 'error');
    });
}

// Initialize dashboard when DOM is loaded
let dashboard;
document.addEventListener('DOMContentLoaded', () => {
    dashboard = new CardSharingDashboard();
});